//neon number
#include<stdio.h>
int main()
{
int n,sq,n2,sum=0,num,d;
printf("enter the number:");
scanf("%d",&n);
n=num;
sq=n*n;
while(sq>0)
{
d=sq%10;
sum=sum+d;
sq=sq/10;

}
/*(n==sum)?printf("number is neon"):printf("not a neon");
}*/
if(num==sum)
{
printf("the number is a neon number");
}
else
{
printf("not a neon number");
}
return 0;
}
