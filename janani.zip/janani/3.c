#include<stdio.h>
#include<math.h>
int main()
{
int num,n,n1,l,sum=0;
printf("enter the number");
scanf("%d",&num);
n=num;
l=log10(num)+1;
while(n1>0)
{
n=num%10;
sum=sum+Pow(n,l);
n1=num/10;
}
(sum==n)?printf("armstrong num"):printf("not an armstrong");
return 0;
}
