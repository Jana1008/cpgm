#include<stdio.h>
int main()
{
int num;
printf("enter the number");
scanf("%d",&num);
(num>0)?printf("the number is positive"):(num<0)?printf("the number is negative"):printf("the number is 0");
return 0;
}
